# evoting_app
Learn how to build a secure voting platform with Django.
